ssh FAREAST.hadong@gcrsandbox488.redmond.corp.microsoft.com << EOF
tmux a -t llama
cd ~/llama-2-table
git pull
/home/hadong/miniconda3/envs/llama/bin/pip install -e .
/home/hadong/miniconda3/envs/llama/bin/torchrun --nnodes 1 --nproc_per_node 4 src/llama_recipes/finetuning.py --enable_fsdp  --use_peft --peft_method lora --pure_bf16 --num_epochs 3
EOF